package com.example.a0311

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity() {
    private lateinit var spinner1: Spinner
    private lateinit var spinner2: Spinner
    private lateinit var textView1: TextView
    private lateinit var button1: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinner1 = findViewById<Spinner>(R.id.spinner1)
        spinner2 = findViewById<Spinner>(R.id.spinner2)
        textView1 = findViewById<TextView>(R.id.textView1)
        button1 = findViewById<Button>(R.id.button1)

        val adapter_Spinner1 = ArrayAdapter.createFromResource(
            this,
            R.array.spinner1,
            android.R.layout.simple_spinner_item
        )

        var items2 = arrayOfNulls<String>(101)
        for (i in 0..99) {
            items2[i] = "第" + (i+1) + "號"
        }

        val adapter_Spinner2 = ArrayAdapter(this, android.R.layout.simple_spinner_item, items2)

        adapter_Spinner1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        adapter_Spinner2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner1.adapter=adapter_Spinner1
        spinner2.adapter=adapter_Spinner2

        button1.setOnClickListener(button1Listener1)

        spinner2.setOnItemSelectedListener(SpinnerSelectedListener_Spinner2)
    }
    var button1Listener1 = View.OnClickListener {
        textView1.text = "您選擇的為\n"+"["+spinner1.getSelectedItemPosition()+"] " + spinner1.getSelectedItem()+"\n"+"["+spinner2.getSelectedItemPosition()+"] " + spinner2.getSelectedItem()
    }
    val SpinnerSelectedListener_Spinner2: AdapterView.OnItemSelectedListener =
        object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View, pos: Int, id: Long) {
                var sSex = parent?.selectedItem.toString()
                textView1.text = "座號變更為 $sSex "
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
        }

}