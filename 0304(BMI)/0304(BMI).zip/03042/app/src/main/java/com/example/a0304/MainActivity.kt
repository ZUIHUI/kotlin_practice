package com.example.a0304

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {
    private lateinit var textView3: TextView
    private lateinit var editText1: EditText
    private lateinit var editText2: EditText
    private lateinit var button1: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView3 = findViewById<TextView>(R.id.textView3)
        editText1 = findViewById<EditText>(R.id.editText1)
        editText2 = findViewById<EditText>(R.id.editText2)
        button1 = findViewById<Button>(R.id.button1)
        button1.setOnClickListener(mListener)
    }
    @SuppressLint("SetTextI18n")
    var mListener = View.OnClickListener {
        var a = editText1.text.toString().toFloat() /100f
        var b = editText2.text.toString().toFloat()
        var c = b / (a*a)
        val dec = DecimalFormat("###,###,###.00")
        val bmi = dec.format(c)

        if (c < 18.5) {
            textView3.text = "BMI = $bmi(體重過輕)"
        } else if (c >= 24) {
            textView3.text = "BMI = $bmi(體重過重)"
        } else {
            textView3.text = "BMI = $bmi(體重正常)"
        }
    }
}

