package com.example.exam1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var textView1: TextView
    private lateinit var editText1: EditText
    private lateinit var button1: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView1 = findViewById<TextView>(R.id.textView1)
        editText1 = findViewById<EditText>(R.id.editText1)
        button1 = findViewById<Button>(R.id.button1)

        button1.setOnClickListener(mListener)
    }

   val mListener = View.OnClickListener {
        val a = editText1.text.toString().toInt()
        val b = a % 2
        textView1.text = "$a 為正數"
        if (a > 0){
            textView1.text = "$a 為正數"
            if (b == 0){
                textView1.text = "$a 為正偶數"
            } else {
                textView1.text = "$a 為正奇數"
            }
        } else if( a < 0 ){
            if (b == 0){
                textView1.text = "$a 為負偶數"
            } else {
                textView1.text = "$a 為負奇數"
            }
        } else {
            textView1.text = "此數為 0"
        }
    }
}


