package com.example.a0401

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.io.*

class MainActivity : AppCompatActivity() {
    private lateinit var editText1 : EditText
    private lateinit var textView1 : TextView
    private lateinit var button1 : Button
    private lateinit var button2 : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText1 = findViewById<EditText>(R.id.editText1)
        textView1 = findViewById<TextView>(R.id.textView1)
        button1 = findViewById<Button>(R.id.button1)
        button2 = findViewById<Button>(R.id.button2)

        val FilePath = getFilesDir().toString() + "/MyPath/"
        val FileName1 = FilePath + "File1.txt"
        val br: BufferedReader
        try {
            br = BufferedReader(InputStreamReader(FileInputStream(FileName1), "UTF-8"))
            var line: String?
            var lines: String = ""
            //不斷的讀入一行字串，直到檔案結尾
            do {
                line = br.readLine()
                if( line != null){
                    lines += line + "\n"
                }
            } while (line != null)
            br.close()
            textView1.text = lines
        }
        catch (e: IOException) {
            e.printStackTrace()
        }

        button1.setOnClickListener(bwf)
        button2.setOnClickListener(brf)
    }

    private var bwf = View.OnClickListener {
        val FilePath = getFilesDir().toString() + "/MyPath/"
        val FileName1 = FilePath + "File1.txt"
        val data = textView1.text.toString() + editText1.text.toString()
        val dirFile = File(FilePath)
        // 如果資料夾不存在，則建立資料夾
        if (!dirFile.exists()) {
            dirFile.mkdirs()
        }
        val bw: BufferedWriter
        try {
            bw = BufferedWriter(OutputStreamWriter(FileOutputStream(FileName1), "UTF-8"))
            bw.write(data)
            bw.close()
        }
        catch (e: IOException) {
        // TODO Auto-generated catch block
            e.printStackTrace()
        }
    }

    private var brf = View.OnClickListener{
        val FilePath = getFilesDir().toString() + "/MyPath/"
        val FileName1 = FilePath + "File1.txt"
        val br: BufferedReader
        try {
            br = BufferedReader(InputStreamReader(FileInputStream(FileName1), "UTF-8"))
            var line: String?
            var lines: String = ""
            //不斷的讀入一行字串，直到檔案結尾
            do {
                line = br.readLine()
                if( line != null){
                    lines += line + "\n"
                }
            } while (line != null)
            br.close()
            textView1.text = lines
        }
        catch (e: IOException) {
            e.printStackTrace()
        }
    }
}