package com.example.a0422

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var button_main : Button
    private lateinit var textView_main : TextView
    private lateinit var editText_main: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView_main = findViewById<TextView>(R.id.textView_main)
        editText_main = findViewById<EditText>(R.id.editText_main)
        button_main = findViewById<Button>(R.id.button_main)

        button_main.setOnClickListener(mListener)
    }
    var mListener = View.OnClickListener {

        val intent = Intent(this, MainActivity2::class.java)
        intent.putExtra("name", editText_main.text.toString())
        startActivity(intent)
    }
}