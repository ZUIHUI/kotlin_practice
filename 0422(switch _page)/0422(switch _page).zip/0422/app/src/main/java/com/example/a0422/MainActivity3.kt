package com.example.a0422

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {
    private lateinit var button_main3 : Button
    private lateinit var textView_main3: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        textView_main3 = findViewById<TextView>(R.id.textView_main3)
        button_main3 = findViewById<Button>(R.id.button_main3)


        val data= intent.getStringExtra("data")

        textView_main3.text = "你的餐點 :\n" + data.toString()

        button_main3.setOnClickListener(BackListener)
    }
    var BackListener = View.OnClickListener {
        val intent = Intent()
        intent.setClass(this, MainActivity::class.java)
        startActivity(intent)
        System.exit(0)
    }
}