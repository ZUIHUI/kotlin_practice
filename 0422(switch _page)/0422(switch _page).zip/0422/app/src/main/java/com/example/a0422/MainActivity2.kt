package com.example.a0422

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity2 : AppCompatActivity() {
    private lateinit var button_main2_1 : Button
    private lateinit var button_main2_2 : Button
    private lateinit var textView_main2 : TextView
    private lateinit var textView_main2_1 : TextView
    private lateinit var radioGroup1: RadioGroup
    private lateinit var checkBox1: CheckBox
    private lateinit var checkBox2: CheckBox
    private lateinit var checkBox3: CheckBox
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val name= intent.getStringExtra("name")

        textView_main2 = findViewById<TextView>(R.id.textView_main2)
        textView_main2_1 = findViewById<TextView>(R.id.textView_main2_1)
        radioGroup1 = findViewById<RadioGroup>(R.id.radioGroup1)
        button_main2_1 = findViewById<Button>(R.id.button_main2_1)
        button_main2_2 = findViewById<Button>(R.id.button_main2_2)
        checkBox1 = findViewById<CheckBox>(R.id.checkBox1)
        checkBox2 = findViewById<CheckBox>(R.id.checkBox2)
        checkBox3 = findViewById<CheckBox>(R.id.checkBox3)


        textView_main2.text = "早安\n" + name.toString()
        button_main2_1.setOnClickListener(sumbitListener)
        button_main2_2.setOnClickListener(BackListener)
    }

    var BackListener = View.OnClickListener {
        val intent = Intent()
        intent.setClass(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    var sumbitListener = View.OnClickListener {
        if (checkBox1.isChecked and checkBox2.isChecked and checkBox3.isChecked){
            textView_main2.text = "Food : \n" + checkBox1.text + "\n" +checkBox2.text + "\n" +checkBox3.text
        } else if (checkBox1.isChecked and checkBox2.isChecked){
            textView_main2.text = "Food :  \n" + checkBox1.text + "\n" +checkBox2.text
        } else if (checkBox1.isChecked and checkBox3.isChecked){
            textView_main2.text = "Food :  \n" + checkBox1.text + "\n" +checkBox3.text
        } else if (checkBox2.isChecked and checkBox3.isChecked){
            textView_main2.text = "Food :  \n" + checkBox2.text + "\n" +checkBox3.text
        } else if (checkBox1.isChecked){
            textView_main2.text = "Food :  \n" + checkBox1.text
        } else if (checkBox2.isChecked){
            textView_main2.text = "Food :  \n" + checkBox2.text
        } else if (checkBox3.isChecked){
            textView_main2.text = "Food : \n" + checkBox3.text
        } else {
            textView_main2.text = "沒有選取"
        }
        val radioB: RadioButton = findViewById (radioGroup1.checkedRadioButtonId)
        textView_main2_1.text = "Drink :" + radioB.text

        val intent = Intent()
        val send_data = textView_main2.text.toString() + "\n" + textView_main2_1.text.toString()

        intent.setClass(this, MainActivity3::class.java)
        intent.putExtra("data", send_data)
        startActivity(intent)
    }
}