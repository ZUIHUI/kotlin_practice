package com.example.a0318

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*


class MainActivity : AppCompatActivity() {
    private lateinit var textView1: TextView
    private lateinit var textView2: TextView
    private lateinit var radioGroup1: RadioGroup
    private lateinit var button1: Button
    private lateinit var button2: Button
    private lateinit var checkBox1: CheckBox
    private lateinit var checkBox2: CheckBox
    private lateinit var checkBox3: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView1 = findViewById<TextView>(R.id.textView1)
        textView2 = findViewById<TextView>(R.id.textView2)
        radioGroup1 = findViewById<RadioGroup>(R.id.radioGroup1)
        button1 = findViewById<Button>(R.id.button1)
        button2 = findViewById<Button>(R.id.button2)
        checkBox1 = findViewById<CheckBox>(R.id.checkBox1)
        checkBox2 = findViewById<CheckBox>(R.id.checkBox2)
        checkBox3 = findViewById<CheckBox>(R.id.checkBox3)

        radioGroup1.setOnCheckedChangeListener(mRadioChecked)
        checkBox1.setOnCheckedChangeListener(mCheckBox)
        checkBox2.setOnCheckedChangeListener(mCheckBox)
        checkBox3.setOnCheckedChangeListener(mCheckBox)
        button1.setOnClickListener(radioListener)
        button2.setOnClickListener(checkListener)
    }

    private val mRadioChecked = RadioGroup.OnCheckedChangeListener { group, checkedId ->
        val radioL: RadioButton = findViewById (checkedId)
        textView1.text = "變更成 " + radioL.text
    }

    private val radioListener = View.OnClickListener {
        val radioB: RadioButton = findViewById (radioGroup1.checkedRadioButtonId)
        textView1.text = "您選擇的為 " + radioB.text
    }

    private val mCheckBox = CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
        val mCheckB: CheckBox = findViewById(buttonView.id)
        if(mCheckB.isChecked) {
            textView2.text = mCheckB.text.toString() + "已選取\n"
        }else{
            textView2.text = mCheckB.text.toString() + "已取消選取\n"
        }
    }

    private val checkListener = View.OnClickListener {
        if (checkBox1.isChecked and checkBox2.isChecked and checkBox3.isChecked){
            textView2.text = "以下項目已被選取: \n" + checkBox1.text + "\n" +checkBox2.text + "\n" +checkBox3.text
        } else if (checkBox1.isChecked and checkBox2.isChecked){
            textView2.text = "以下項目已被選取: \n" + checkBox1.text + "\n" +checkBox2.text
        } else if (checkBox1.isChecked and checkBox3.isChecked){
            textView2.text = "以下項目已被選取: \n" + checkBox1.text + "\n" +checkBox3.text
        } else if (checkBox2.isChecked and checkBox3.isChecked){
            textView2.text = "以下項目已被選取: \n" + checkBox2.text + "\n" +checkBox3.text
        } else if (checkBox1.isChecked){
            textView2.text = "以下項目已被選取: \n" + checkBox1.text
        } else if (checkBox2.isChecked){
            textView2.text = "以下項目已被選取: \n" + checkBox2.text
        } else if (checkBox3.isChecked){
            textView2.text = "以下項目已被選取: \n" + checkBox3.text
        } else {
            textView2.text = "沒有選取"
        }
    }
}