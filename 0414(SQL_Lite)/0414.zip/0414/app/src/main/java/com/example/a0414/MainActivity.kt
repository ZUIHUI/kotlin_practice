package com.example.a0414

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.widget.*

class MainActivity : AppCompatActivity() {
    private lateinit var editText1: EditText
    private lateinit var editText2: EditText
    private lateinit var button1: Button
    private lateinit var button2: Button
    private lateinit var button3: Button
    private lateinit var button4: Button
    private lateinit var textView3: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val DB_FILE = "friends.db"
        val DB_TABLE = "friends"
        val MyDB: SQLiteDatabase
        // 建立自訂的 FriendDbHelper 物件
        val friDbHp = MyDBHelper(applicationContext, DB_FILE, null, 1)
        // 設定建立 table 的指令
        friDbHp.sCreateTableCommand = "CREATE TABLE " + DB_TABLE + "(" +
                "id INTEGER PRIMARY KEY," +
                "name TEXT NOT NULL)"
        // 取得上面指定的檔名資料庫，如果該檔名不存在就會自動建立一個資料庫檔案
        MyDB = friDbHp.writableDatabase

        editText1 = findViewById<EditText>(R.id.editText1)
        editText2 = findViewById<EditText>(R.id.editText2)
        button1 = findViewById<Button>(R.id.button1)
        button2 = findViewById<Button>(R.id.button2)
        button3 = findViewById<Button>(R.id.button3)
        button4 = findViewById<Button>(R.id.button4)
        textView3 = findViewById<TextView>(R.id.textView3)

        button1.setOnClickListener {
            val c = MyDB.query(
                true, DB_TABLE, arrayOf("id","name"),
                null, null, null, null, null, null
            )
            // 宣告一ContentValues
            val newRow = ContentValues()
            // 將要新增的欄位"id","name"放入ContentValues中
            newRow.put("id", editText1.text.toString().toInt())
            newRow.put("name", editText2.text.toString())
            // 將ContentValues中的資料，放至資料表中
            MyDB.insert(DB_TABLE, null, newRow)

            c.moveToFirst();
            textView3.text = c.getString(0) + "\t" + c.getString(1)
            while (c.moveToNext()) {
                textView3.append("\n" + c.getString(0) + "\t" + c.getString(1))
            }
        }
        button2.setOnClickListener {
            val c = MyDB.query(
                true, DB_TABLE, arrayOf("id","name"),
                null, null, null, null, null, null
            )
            // 宣告一ContentValues
            val newRow = ContentValues()
            val DB_TABLE = "friends"
            val rowid = editText1.text.toString().toInt()
            // 將要新增的欄位"name","sex"與"address"，放入ContentValues中
            newRow.put("id", editText1.text.toString().toInt())
            newRow.put("name", editText2.text.toString())
            // 將ContentValues中的資料，放至資料表中
            MyDB.update(DB_TABLE, newRow, "id=$rowid", null)

            c.moveToFirst();
            textView3.text = c.getString(0) + "\t" + c.getString(1)
            while (c.moveToNext()) {
                textView3.append("\n" + c.getString(0) + "\t" + c.getString(1))
            }
        }
        button3.setOnClickListener {
            val c = MyDB.query(
                true, DB_TABLE, arrayOf("id","name"),
                null, null, null, null, null, null
            )
            val rowid = editText1.text.toString().toInt()
            MyDB.delete(DB_TABLE, "id=$rowid", null)

            if (c.count === 0) {
                textView3.text = ""
                Toast.makeText(this, "沒有資料", Toast.LENGTH_LONG).show()
            } else {
                c.moveToFirst();
                textView3.text = c.getString(0) + "\t" + c.getString(1)
                while (c.moveToNext()) {
                    textView3.append("\n" + c.getString(0) + "\t" + c.getString(1))
                }
            }

        }
        button4.setOnClickListener {
            val c = MyDB.query(
                true, DB_TABLE, arrayOf("id","name"),
                null, null, null, null, null, null
            )
            if (c.count === 0) {
                textView3.text = ""
                Toast.makeText(this, "沒有資料", Toast.LENGTH_LONG).show()
            } else {
                c.moveToFirst();
                textView3.text = c.getString(0) + "\t" + c.getString(1)
                while (c.moveToNext()) {
                    textView3.append("\n" + c.getString(0) + "\t" + c.getString(1))
                }
            }
        }
    }
}
