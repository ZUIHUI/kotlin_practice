package com.example.imageview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    private lateinit var button1: Button
    private lateinit var editText1: EditText
    private lateinit var imageButton1: ImageButton
    private lateinit var imageView1: ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // 從資源類別R中取得介面元件
        button1 = findViewById<Button>(R.id.button1)
        editText1 = findViewById<EditText>(R.id.editText1)
        imageButton1 = findViewById<ImageButton>(R.id.imageButton1)
        imageView1 = findViewById<ImageView>(R.id.imageView1)
        // 設定ImageButton元件的Listener事件
        imageButton1.setOnClickListener(mListener)
        button1.setOnClickListener(switchListener)
    }

    var mListener = View.OnClickListener {
        val num = editText1.text.toString()
        if (num == "1") {
            imageView1.setImageResource(R.drawable.dice_1)
        } else if (num == "2") {
            imageView1.setImageResource(R.drawable.dice_2)
        } else if (num == "3") {
            imageView1.setImageResource(R.drawable.dice_3)
        } else if (num == "4") {
            imageView1.setImageResource(R.drawable.dice_4)
        } else if (num == "5") {
            imageView1.setImageResource(R.drawable.dice_5)
        } else if (num == "6") {
            imageView1.setImageResource(R.drawable.dice_6)
        }else{
            imageView1.setImageResource(R.drawable.error)
        }
    }

    var switchListener = View.OnClickListener {
        val intent = Intent(this, MainActivity2::class.java)
        startActivity(intent)
    }
}