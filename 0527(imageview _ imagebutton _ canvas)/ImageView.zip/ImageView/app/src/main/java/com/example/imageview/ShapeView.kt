package com.example.imageview

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.OvalShape
import android.view.View
import androidx.core.content.res.ResourcesCompat

class ShapeView(context: Context?) : View(context) {

    private var mShapeDraw: ShapeDrawable = ShapeDrawable(OvalShape())
    private lateinit var mPaint: Paint
    private lateinit var tPaint: Paint

    // 為以上兩變數，設定初始設定
    init {
        mShapeDraw.paint.color = Color.rgb(255,255,255)
        mPaint = Paint()
        mPaint.setAntiAlias(true)
        mPaint.setColor(Color.BLUE)
        mPaint.strokeWidth = 5f
    }
    init {
        mShapeDraw.paint.color = Color.rgb(255,255,255)
        tPaint = Paint()
        tPaint.setAntiAlias(true)
        tPaint.setColor(Color.RED)
        tPaint.textSize = 48f
        tPaint.strokeWidth = 5f
    }
    protected override fun onDraw(canvas: Canvas) {
    //TODO Auto-generated method stub
        super.onDraw(canvas)
        mShapeDraw.setBounds(10, 10, getWidth() / 2 - 10, getHeight() / 2 - 20)
        mShapeDraw.draw(canvas)
        canvas.drawCircle(getWidth() / 2 + 10f, 370f, 300f, mPaint)
        canvas.drawText("HI!下面這顆是圓形喔!我不知道我在畫甚麼",getWidth() / 10f,getHeight() / 30f, tPaint)
        canvas.drawLine(getWidth() / 2 + 20f,getHeight()/ 2f+ 60f,getWidth() - 1f,getHeight()/ 2f, tPaint)
        canvas.drawLine(getWidth() / 2 + 20f,getHeight()/ 2f+ 60f,getWidth() - 1f,getHeight() / 2 - 480f, tPaint)
        canvas.drawLine(getWidth() / 2 + 20f,getHeight()/ 2f+ 60f,getWidth() - 1f,getHeight() / 2 + 480f, tPaint)
        canvas.drawLine(getWidth() / 2 + 20f,getHeight()/ 2f+ 60f,getWidth() - 1500f,getHeight() / 2f, tPaint)
        canvas.drawLine(getWidth() / 2 + 20f,getHeight()/ 2f+ 60f,getWidth() - 1500f,getHeight() / 2f - 800f, tPaint)
        canvas.drawLine(getWidth() / 2 + 20f,getHeight()/ 2f+ 60f,getWidth() - 1500f,getHeight() / 2f + 800f, tPaint)
        canvas.drawText("????",getWidth() / 2f - 40f,getHeight() / 2 + 500f, tPaint)
        var drawImg = ResourcesCompat.getDrawable(getResources(), R.drawable.img, null)!!
        drawImg.setBounds(300,getWidth() / 2 + 120,getWidth() - 300,getHeight() / 2 + 250)
        drawImg.draw(canvas)
    }
}
