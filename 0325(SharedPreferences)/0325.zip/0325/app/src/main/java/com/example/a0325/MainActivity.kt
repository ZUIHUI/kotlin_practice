package com.example.a0325

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var textView1: TextView
    private lateinit var editText1: EditText
    private lateinit var button1: Button
    private lateinit var button2: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView1 = findViewById<TextView>(R.id.textView1)
        editText1 = findViewById<EditText>(R.id.editText1)
        button1 = findViewById<Button>(R.id.button1)
        button2 = findViewById<Button>(R.id.button2)

        button1.setOnClickListener(write)
        button2.setOnClickListener(read)
    }
    private val write = View.OnClickListener {
        val text = textView1.text.toString() +"\n"+ editText1.text.toString()
        val MySetting = getSharedPreferences("UserDefault", 0)
        MySetting.edit()
            .putString("text",text)
            .commit()
    }
    private val read = View.OnClickListener {
        val MySetting = getSharedPreferences("UserDefault", 0)
        var MyString = MySetting.getString("text", "No value")
        textView1.text = MyString
    }
}